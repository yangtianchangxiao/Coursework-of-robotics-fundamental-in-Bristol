clc
clear all
syms d1 d2 s L theta1 theta2 theta3;
syms xpp1 xpp2 xpp3 ypp1 ypp2 ypp3;
syms xc yc a;
angle = input('Input orientation a: ');
xpp1 = xc-cos(a+pi/6)*d2/sqrt(3);
ypp1 = yc-sin(a+pi/6)*d2/sqrt(3);
eqn1 = (xpp1-s*cos(theta1)).^2 + (ypp1-s*sin(theta1)).^2 -L*L == 0;
Ans1 = solve(eqn1,theta1);
Ans1 = simplify(Ans1);
xpp2 = xpp1 + d2*cos(a+pi/3);
ypp2 = ypp1 + d2*sin(a+pi/3);
xpp3 = xpp1 + d2*cos(a);
ypp3 = ypp1 + d2*sin(a);
eqn2 = (xpp2-(d1/2+s*cos(theta2))).^2+(ypp2-(d1/2*sqrt(3)+s*sin(theta2))).^2 - L*L == 0;
eqn3 = (xpp3-(d1+s*cos(theta3))).^2+(ypp3-s*sin(theta3)).^2 - L*L ==0;
Ans2 = simplify(solve(eqn2,theta2));
Ans3 = simplify(solve(eqn3,theta3));

Ans1 = subs(Ans1,{d1,d2,s,L},{500,250,160,140});
Ans1_1 = Ans1;
Ans2 = subs(Ans2,{d1,d2,s,L},{500,250,160,140});
Ans3 = subs(Ans3,{d1,d2,s,L},{500,250,160,140});
Ans2_1 = Ans2;
Ans3_1 = Ans3;
x = linspace(0,500,200);
y = linspace(-73,427,200);
x_work = [];
y_work = [];

times = 0;
for j = 1:200
    Ans1 = double(subs(Ans1_1,{xc,yc,a},{x(j),y,angle}));
    Ans2 = double(subs(Ans2_1,{xc,yc,a},{x(j),y,angle}));
    Ans3 = double(subs(Ans3_1,{xc,yc,a},{x(j),y,angle}));

    ANS1 = Ans1(1,:);
    ANS2 = Ans2(1,:);
    ANS3 = Ans3(2,:);
    times = times +  1

    %ANS1(abs(imag(ANS1))<eps(ANS1));

    for i = 1:200
        if(   ((abs(imag(ANS1(i)))<eps(ANS1(i)))>0)&&((abs(imag(ANS2(i)))<eps(ANS2(i)))>0)&&((abs(imag(ANS3(i)))<eps(ANS3(i)))>0)   )
            x_work = [x_work x(j)];
            y_work = [y_work y(i)];
        end
    end
end
m= size(x_work);
plot(x_work,y_work,'.')

% xc=200;
% yc=300;
% a=pi/6;
% 
% d1 = 500;
% d2 = 250;
% s = 160;
% L = 140;
% 
% xpp1 = xc-cos(a+pi/6)*d2/sqrt(3);
% ypp1 = yc-sin(a+pi/6)*d2/sqrt(3);
% xpp2 = xpp1 + d2*cos(a+pi/3);
% ypp2 = ypp1 + d2*sin(a+pi/3);
% xpp3 = xpp1 + d2*cos(a);
% ypp3 = xpp1 + d2*sin(a);
% 
% 
% double(Ans1)
% double(Ans2)
% double(Ans3)
% figure(1)
% plot([0,d1,d1/2,0],[0,0,d1/2*sqrt(3),0],'b')
% hold on;
% 
% plot([0,s*cos(Ans1(1))],[0,s*sin(Ans1(1))],'g')
% plot([d1,d1+s*cos(Ans2(1))],[0,s*sin(Ans2(1))],'g')
% plot([d1/2,d1/2+s*cos(Ans3(1))],[d1/2*sqrt(3),d1/2*sqrt(3)+s*sin(Ans3(1))],'g')
% 
% plot([xpp1,xpp2,xpp3,xpp1],[ypp1,ypp2,ypp3,ypp1],'r')
% 
% plot([s*cos(Ans1(1)),xpp1],[s*sin(Ans1(1)),ypp1],'k')
% plot([d1/2+s*cos(Ans3(1)),xpp2],[d1/2*sqrt(3)+s*sin(Ans3(1)),ypp2],'k')
% plot([d1+s*cos(Ans2(1)),xpp3],[s*sin(Ans2(1)),ypp3],'k')

clc
clear all
syms d1 d2 s L theta1 theta2 theta3;
syms xpp1 xpp2 xpp3 ypp1 ypp2 ypp3;
syms xc yc a;
xpp1 = xc-cos(a+pi/6)*d2/sqrt(3);
ypp1 = yc-sin(a+pi/6)*d2/sqrt(3);
eqn1 = (xpp1-s*cos(theta1)).^2 + (ypp1-s*sin(theta1)).^2 -L*L == 0;
Ans1=solve(eqn1,theta1);
Ans = simplify(Ans1);
xpp2 = xpp1 + d2*cos(a+pi/3);
ypp2 = ypp1 + d2*sin(a+pi/3);
xpp3 = xpp1 + d2*cos(a);
ypp3 = ypp1 + d2*sin(a);
eqn2 = (xpp2-(d1/2+s*cos(theta2))).^2+(ypp2-(d1/2*sqrt(3)+s*sin(theta2))).^2 - L*L == 0;
eqn3 = (xpp3-(d1+s*cos(theta3))).^2+(ypp3-s*sin(theta3)).^2 - L*L ==0;
Ans2 = simplify(solve(eqn2,theta2));
Ans3 = simplify(solve(eqn3,theta3));

Ans1 = subs(Ans1,{d1,d2,s,L},{500,250,160,140});
Ans2 = subs(Ans2,{d1,d2,s,L},{500,250,160,140});
Ans3 = subs(Ans3,{d1,d2,s,L},{500,250,160,140});

Ans1 = subs(Ans1,{xc,yc,a},{200,300,0});
Ans2 = subs(Ans2,{xc,yc,a},{200,300,0});
Ans3 = subs(Ans3,{xc,yc,a},{200,300,0});

xc=200;
yc=300;
a=0;

d1 = 500;
d2 = 250;
s = 160;
L = 140;

xpp1 = xc-cos(a+pi/6)*d2/sqrt(3);
ypp1 = yc-sin(a+pi/6)*d2/sqrt(3)
xpp2 = xpp1 + d2*cos(a+pi/3);
ypp2 = ypp1 + d2*sin(a+pi/3);
xpp3 = xpp1 + d2*cos(a);
ypp3 = ypp1 + d2*sin(a);


double(Ans1)
double(Ans2)
double(Ans3)
figure(1)


plot([0,d1,d1/2,0],[0,0,d1/2*sqrt(3),0],'b')
hold on;

plot([0,s*cos(Ans1(1))],[0,s*sin(Ans1(1))],'g')
plot([d1,d1+s*cos(Ans2(2))],[0,s*sin(Ans2(2))],'g')
plot([d1/2,d1/2+s*cos(Ans3(1))],[d1/2*sqrt(3),d1/2*sqrt(3)+s*sin(Ans3(1))],'g')

plot([xpp1,xpp2,xpp3,xpp1],[ypp1,ypp2,ypp3,ypp1],'r')

plot([s*cos(Ans1(1)),xpp1],[s*sin(Ans1(1)),ypp1],'k')
plot([d1/2+s*cos(Ans3(1)),xpp2],[d1/2*sqrt(3)+s*sin(Ans3(1)),ypp2],'k')
plot([d1+s*cos(Ans2(2)),xpp3],[s*sin(Ans2(2)),ypp3],'k')
xlim([0, 600])
ylim([0, 600])
set(gca,'XTick',0:50:600);
set(gca,'YTick',0:50:600);
